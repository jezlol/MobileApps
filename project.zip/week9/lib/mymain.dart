import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

main() {
  runApp(const ShowInf());
}

class ShowInf extends StatefulWidget {
  const ShowInf({super.key});

  @override
  State<ShowInf> createState() => _ShowInfState();
}

class _ShowInfState extends State<ShowInf> {
  List list = [];
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();
  final TextEditingController _heightController = TextEditingController();
  final TextEditingController _weightController = TextEditingController();

  // ตัวแปรเก็บค่า BMI
  String bmiResult = '';
  String bmiType = '';

  // ฟังก์ชันคำนวณ BMI แบบง่ายๆ
  void calculateBMI() {
    try {
      // ตรวจสอบว่ามีการกรอกข้อมูลครบไหม
      if (_heightController.text.isEmpty || _weightController.text.isEmpty) {
        setState(() {
          bmiResult = '';
          bmiType = '';
        });
        return;
      }

      // แปลงข้อความเป็นตัวเลข
      double height = double.parse(_heightController.text);
      double weight = double.parse(_weightController.text);

      // ตรวจสอบค่าที่รับเข้ามา
      if (height <= 0 || weight <= 0) {
        setState(() {
          bmiResult = '';
          bmiType = '';
        });
        return;
      }

      // คำนวณ BMI
      double heightInMeter = height / 100; // แปลง cm เป็น m
      double bmi = weight / (heightInMeter * heightInMeter);

      // กำหนดประเภท BMI
      String type = '';
      if (bmi < 18.5) {
        type = 'Underweight';
      } else if (bmi < 25) {
        type = 'Normal';
      } else if (bmi < 30) {
        type = 'Overweight';
      } else {
        type = 'Obese';
      }

      // อัพเดทค่าที่จะแสดงผล
      setState(() {
        bmiResult = bmi.toStringAsFixed(2); // แสดงทศนิยม 2 ตำแหน่ง
        bmiType = type;
      });
    } catch (e) {
      // ถ้าเกิดข้อผิดพลาด (เช่น ข้อมูลไม่ถูกต้อง)
      setState(() {
        bmiResult = '';
        bmiType = '';
      });
      print('Error calculating BMI: $e');
    }
  }

  Future<String> listData() async {
    var response = await http.get(Uri.http('10.0.2.2:8080', 'emp'),
        headers: {"Accept": "application/json"});
    print('Response status: ${response.statusCode}');
    print('Response body: ${response.body}');
    setState(() {
      list = jsonDecode(response.body);
    });
    return "Success";
  }

  @override
  void initState() {
    super.initState();
    listData();

    // เพิ่ม listeners สำหรับการคำนวณ BMI อัตโนมัติ
    _heightController.addListener(calculateBMI);
    _weightController.addListener(calculateBMI);
  }

  @override
  void dispose() {
    // ลบ listeners เมื่อ widget ถูกทำลาย
    _heightController.removeListener(calculateBMI);
    _weightController.removeListener(calculateBMI);
    _heightController.dispose();
    _weightController.dispose();
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _addressController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: const Text('DB Test'),
        ),
        body: Center(
          child: ListView.builder(
              itemCount: list.length,
              itemBuilder: (BuildContext context, int index) {
                return Card(
                  child: ListTile(
                    title: Row(
                      children: [
                        Expanded(child: Text(list[index]["name"])),
                        Expanded(child: Text(list[index]["email"]))
                      ],
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Phone: ${list[index]["phone"]}'),
                        Text('Address: ${list[index]["address"]}'),
                        Text('Height: ${list[index]["height"]} cm'),
                        Text('Weight: ${list[index]["weight"]} kg'),
                        Text(
                            'BMI: ${list[index]["bmi"]} (${list[index]["bmi_type"]})'),
                      ],
                    ),
                    leading: Text(list[index]["id"].toString()),
                    trailing: Wrap(
                      spacing: 5,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.edit, color: Colors.green),
                          onPressed: () {
                            Map data = {
                              'id': list[index]['id'],
                              'name': list[index]['name'],
                              'email': list[index]['email'],
                              'phone': list[index]['phone'],
                              'address': list[index]['address'],
                              'height': list[index]['height']?.toString() ?? '',
                              'weight': list[index]['weight']?.toString() ?? '',
                            };
                            _showedit(data);
                          },
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete_outline,
                              color: Colors.red),
                          onPressed: () => _showDel(list[index]["id"]),
                        )
                      ],
                    ),
                  ),
                );
              }),
        ),
        floatingActionButton: FloatingActionButton(
          child: const Icon(Icons.add),
          onPressed: () {
            _addNewDialog();
          },
        ),
      ),
    );
  }

  Future<void> _addNewDialog() async {
    // เคลียร์ค่าเก่า
    _nameController.clear();
    _emailController.clear();
    _phoneController.clear();
    _addressController.clear();
    _heightController.clear();
    _weightController.clear();
    bmiResult = '';
    bmiType = '';

    return showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Add New Entry'),
            content: SingleChildScrollView(
              child: Column(
                children: <Widget>[
                  TextField(
                    controller: _nameController,
                    decoration: const InputDecoration(labelText: "Name"),
                  ),
                  TextField(
                    controller: _emailController,
                    decoration: const InputDecoration(labelText: "Email"),
                  ),
                  TextField(
                    controller: _phoneController,
                    decoration: const InputDecoration(labelText: "Phone"),
                  ),
                  TextField(
                    controller: _addressController,
                    decoration: const InputDecoration(labelText: "Address"),
                  ),
                  TextField(
                    controller: _heightController,
                    decoration: const InputDecoration(labelText: "Height (cm)"),
                    keyboardType: TextInputType.number,
                    onChanged: (value) => calculateBMI(),
                  ),
                  TextField(
                    controller: _weightController,
                    decoration: const InputDecoration(labelText: "Weight (kg)"),
                    keyboardType: TextInputType.number,
                    onChanged: (value) => calculateBMI(),
                  ),
                  // แสดงผล BMI
                  if (bmiResult.isNotEmpty) Text('BMI: $bmiResult'),
                  if (bmiType.isNotEmpty) Text('Type: $bmiType'),
                ],
              ),
            ),
            actions: <Widget>[
              TextButton(
                child: const Text('Cancel'),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
              TextButton(
                child: const Text('Save'),
                onPressed: () {
                  add_data();
                  Navigator.of(context).pop();
                },
              ),
            ],
          );
        });
  }

  Future<void> _showedit(Map data) async {
    _nameController.text = data['name'];
    _emailController.text = data['email'];
    _phoneController.text = data['phone'];
    _addressController.text = data['address'];
    _heightController.text = data['height']?.toString() ?? '';
    _weightController.text = data['weight']?.toString() ?? '';
    bmiResult = '';
    bmiType = '';

    return showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Edit Entry'),
            content: SingleChildScrollView(
              child: Column(
                children: <Widget>[
                  TextField(
                    controller: _nameController,
                    decoration: const InputDecoration(labelText: "Name"),
                  ),
                  TextField(
                    controller: _emailController,
                    decoration: const InputDecoration(labelText: "Email"),
                  ),
                  TextField(
                    controller: _phoneController,
                    decoration: const InputDecoration(labelText: "Phone"),
                  ),
                  TextField(
                    controller: _addressController,
                    decoration: const InputDecoration(labelText: "Address"),
                  ),
                  TextField(
                    controller: _heightController,
                    decoration: const InputDecoration(labelText: "Height (cm)"),
                    keyboardType: TextInputType.number,
                    onChanged: (value) => calculateBMI(),
                  ),
                  TextField(
                    controller: _weightController,
                    decoration: const InputDecoration(labelText: "Weight (kg)"),
                    keyboardType: TextInputType.number,
                    onChanged: (value) => calculateBMI(),
                  ),
                  // แสดงผล BMI
                  if (bmiResult.isNotEmpty) Text('BMI: $bmiResult'),
                  if (bmiType.isNotEmpty) Text('Type: $bmiType'),
                ],
              ),
            ),
            actions: <Widget>[
              TextButton(
                child: const Text('Cancel'),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
              TextButton(
                child: const Text('Save'),
                onPressed: () {
                  edit_data(data['id']);
                  Navigator.of(context).pop();
                },
              ),
            ],
          );
        });
  }

  Future<void> _showDel(int id) async {
    return showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Delete Data $id'),
            content: const Text('Are you sure you want to delete this data?'),
            actions: <Widget>[
              TextButton(
                child: const Text('Cancel'),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
              TextButton(
                child: const Text('Delete'),
                onPressed: () {
                  del_data(id);
                  Navigator.of(context).pop();
                },
              ),
            ],
          );
        });
  }

  void add_data() async {
    if (_heightController.text.isEmpty || _weightController.text.isEmpty) {
      print("Height or weight is empty");
      return;
    }

    // Calculate BMI before sending data
    calculateBMI();

    if (bmiResult.isEmpty || bmiType.isEmpty) {
      print("BMI calculation failed");
      return;
    }

    var url = Uri.parse('http://10.0.2.2:8080/create');
    var data = {
      'name': _nameController.text,
      'email': _emailController.text,
      'phone': _phoneController.text,
      'address': _addressController.text,
      'height': double.parse(_heightController.text),
      'weight': double.parse(_weightController.text),
      'bmi': double.parse(bmiResult),
      'bmi_type': bmiType,
    };

    var response = await http.post(url,
        body: json.encode(data), headers: {'Content-Type': 'application/json'});
    if (response.statusCode == 200) {
      _nameController.text = '';
      _emailController.text = '';
      _phoneController.text = '';
      _addressController.text = '';
      _heightController.text = '';
      _weightController.text = '';
      bmiResult = '';
      bmiType = '';
      listData();
    }
  }

  void del_data(int id) async {
    var response = await http.delete(Uri.http('10.0.2.2:8080', 'delete/$id'),
        headers: {
          'Content-Type': 'application/json; charset=UTF-8',
          "Accept": "application/json"
        });
    print('Response status: ${response.statusCode}');
    print('Response body: ${response.body}');
    listData();
  }

  void edit_data(int id) async {
    if (_heightController.text.isEmpty || _weightController.text.isEmpty) {
      print("Height or weight is empty");
      return;
    }

    // Calculate BMI before sending data
    calculateBMI();

    if (bmiResult.isEmpty || bmiType.isEmpty) {
      print("BMI calculation failed");
      return;
    }

    var url = Uri.parse('http://10.0.2.2:8080/update/$id');
    var data = {
      'name': _nameController.text,
      'email': _emailController.text,
      'phone': _phoneController.text,
      'address': _addressController.text,
      'height': double.parse(_heightController.text),
      'weight': double.parse(_weightController.text),
      'bmi': double.parse(bmiResult),
      'bmi_type': bmiType,
    };

    var response = await http.put(url,
        body: json.encode(data), headers: {'Content-Type': 'application/json'});
    if (response.statusCode == 200) {
      _nameController.text = '';
      _emailController.text = '';
      _phoneController.text = '';
      _addressController.text = '';
      _heightController.text = '';
      _weightController.text = '';
      bmiResult = '';
      bmiType = '';
      listData();
    }
  }
}
